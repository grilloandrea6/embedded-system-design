There are three versions of the verilog code:
ramDmaCi_1.v : the solution to ch 2.2.
ramDmaCi_2.v : the solution to ch 2.3.
ramDmaCi.v   : the solution to ch 2.4 (containing all functionality)

